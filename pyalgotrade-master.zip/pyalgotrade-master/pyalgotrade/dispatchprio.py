FIRST = 0

# We want to process order events before bar feed events.
BROKER = 1000
BAR_FEED = 2000

LAST = None
