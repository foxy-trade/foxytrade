Tools
=====

Quandl
------

.. automodule:: pyalgotrade.tools.quandl
    :members:
    :show-inheritance:


BarFeed resampling
------------------

.. automodule:: pyalgotrade.tools.resample
    :members:
    :show-inheritance:

