plotter -- Strategy plotter
===========================

.. automodule:: pyalgotrade.plotter
    :members: Subplot, InstrumentSubplot, StrategyPlotter
    :show-inheritance:

