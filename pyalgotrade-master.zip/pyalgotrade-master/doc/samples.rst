.. _samples-label:

Sample strategies
=================

Momentum
--------
.. toctree::
    sample_vwap_momentum
    sample_sma_crossover
    sample_market_timing

Mean Reversion
--------------
.. toctree::
    sample_statarb_erniechan
    sample_bbands
    sample_rsi2

Others
------
.. toctree::
    sample_quandl
